CREATE TABLE IF NOT EXISTS "auditoria_evento" (
	"id" UUID NOT NULL UNIQUE,
	"tabela" VARCHAR(255) NOT NULL,
	"operacao" VARCHAR(255) NOT NULL,
	"registro_id" UUID NOT NULL,
	"usuario_id" UUID NOT NULL,
	"entidade_id" UUID NOT NULL,
	"registro_anterior" JSONB,
	"registro_novo" JSONB,
	"created_at" TIMESTAMP NOT NULL,
	PRIMARY KEY("id")
);
