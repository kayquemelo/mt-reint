CREATE TABLE IF NOT EXISTS "dispositivo" (
	"id" UUID NOT NULL UNIQUE,
	"codigo" VARCHAR(255) NOT NULL,
	"nome" VARCHAR(255) NOT NULL,
	"descricao" TEXT NOT NULL,
	"qr_code" TEXT,
	"ativo" BOOLEAN,
	"created_at" TIMESTAMP NOT NULL,
	"created_by" UUID NOT NULL,
	"updated_at" TIMESTAMP,
	"updated_by" UUID,
	"deleted_at" TIMESTAMP,
	"deleted_by" UUID,
	PRIMARY KEY("id")
);
