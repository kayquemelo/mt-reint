CREATE TABLE IF NOT EXISTS "rbac_papel_permissao" (
	"id" UUID NOT NULL,
	"papel_id" UUID NOT NULL,
	"permissao_id" UUID NOT NULL,
	"created_at" TIMESTAMP NOT NULL,
	"created_by" UUID NOT NULL,
	"updated_at" TIMESTAMP,
	"updated_by" UUID,
	"deleted_at" TIMESTAMP,
	"deleted_by" UUID,
	PRIMARY KEY("id")
);