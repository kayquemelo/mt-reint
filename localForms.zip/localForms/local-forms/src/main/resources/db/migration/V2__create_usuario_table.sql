CREATE TABLE IF NOT EXISTS "usuario" (
	"id" UUID NOT NULL UNIQUE,
	"email" VARCHAR(255) NOT NULL UNIQUE,
	"senha" VARCHAR(255) NOT NULL,
	"recuperacao" VARCHAR(255),
	"token" VARCHAR(255),
	"token_expires" TIMESTAMP,
	"ativo" BOOLEAN NOT NULL,
	"created_at" TIMESTAMP NOT NULL,
	"created_by" UUID NOT NULL,
	"updated_at" TIMESTAMP,
	"updated_by" UUID,
	"deleted_at" TIMESTAMP,
	"deleted_by" UUID,
	PRIMARY KEY("id")
);