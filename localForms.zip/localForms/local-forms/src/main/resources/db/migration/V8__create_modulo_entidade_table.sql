CREATE TABLE IF NOT EXISTS "modulo_entidade" (
	"id" UUID NOT NULL UNIQUE,
	"modulo_id" UUID NOT NULL,
	"entidade_id" UUID NOT NULL,
	"ativo" BOOLEAN NOT NULL,
	"created_at" TIMESTAMP NOT NULL,
	"created_by" UUID NOT NULL,
	"updated_at" TIMESTAMP,
	"updated_by" UUID,
	"delete_at" TIMESTAMP,
	"deleted_by" UUID,
	PRIMARY KEY("id")
);
