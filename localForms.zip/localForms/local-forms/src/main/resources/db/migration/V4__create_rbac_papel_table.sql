CREATE TABLE IF NOT EXISTS "rbac_papel" (
	"id" UUID NOT NULL UNIQUE,
	"nome" VARCHAR(255) NOT NULL,
	"descricao" TEXT,
	"entidade_id" UUID NOT NULL,
	"created_at" TIMESTAMP NOT NULL,
	"created_by" UUID NOT NULL,
	"updated_at" TIMESTAMP,
	"updated_by" UUID,
	"deleted_at" TIMESTAMP,
	"deleted_by" UUID,
	PRIMARY KEY("id")
);