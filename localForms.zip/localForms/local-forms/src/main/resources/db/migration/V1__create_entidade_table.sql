CREATE TABLE IF NOT EXISTS "entidade" (
	"id" UUID NOT NULL UNIQUE,
	"codigo" VARCHAR(255) NOT NULL,
	"nome" TEXT NOT NULL,
	"descricao" TEXT,
	"entidade_id" UUID,
	"hostname" VARCHAR(255),
	"limite_entidade" INTEGER,
	"limite_usuario" INTEGER,
	"cor_primaria" VARCHAR(255),
	"cor_secundaria" VARCHAR(255),
	"cor_terciaria" VARCHAR(255),
	"logo_path" TEXT,
	"email_conta" TEXT,
	"email_porta" TEXT,
	"email_senha" TEXT,
	"ativo" BOOLEAN NOT NULL,
	"created_at" TIMESTAMP NOT NULL,
	"created_by" UUID NOT NULL,
	"updated_at" TIMESTAMP,
	"updated_by" UUID,
	"deleted_at" TIMESTAMP,
	"deleted_by" UUID,
	PRIMARY KEY("id")
);

COMMENT ON TABLE "entidade" IS 'Tabela utilizada para armazenar as tenants/filiais/unidades/empresas em hierarquia.';
COMMENT ON COLUMN "entidade"."entidade_id" IS 'UUID da entidade pai. caso seja uma entidade raiz, deixar como null.';