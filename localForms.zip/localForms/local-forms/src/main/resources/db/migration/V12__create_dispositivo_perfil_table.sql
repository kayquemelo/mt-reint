CREATE TABLE IF NOT EXISTS "dispositivo_perfil" (
	"id" UUID NOT NULL UNIQUE,
	"perfil_id" UUID NOT NULL,
	"dispositivo_id" UUID NOT NULL,
	"created_at" TIMESTAMP NOT NULL,
	"created_by" UUID NOT NULL,
	"updated_at" TIMESTAMP,
	"updated_by" UUID,
	"deleted_at" TIMESTAMP,
	"deleted_by" UUID,
	PRIMARY KEY("id")
);
