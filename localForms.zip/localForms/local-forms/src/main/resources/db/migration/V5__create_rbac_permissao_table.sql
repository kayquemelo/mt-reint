CREATE TABLE IF NOT EXISTS "rbac_permissao" (
	"id" UUID NOT NULL UNIQUE,
	"nome" VARCHAR(255) NOT NULL,
	"descricao" TEXT,
	"modulo_id" UUID NOT NULL,
	"acao" VARCHAR(255) NOT NULL,
	"created_at" TIMESTAMP NOT NULL,
	"created_by" UUID NOT NULL,
	"updated_at" TIMESTAMP,
	"updated_by" UUID,
	"deleted_at" TIMESTAMP,
	"deleted_by" UUID,
	PRIMARY KEY("id")
);
