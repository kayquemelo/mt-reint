CREATE TABLE IF NOT EXISTS "usuario_perfil" (
	"id" UUID NOT NULL UNIQUE,
	"nome" TEXT,
	"apelido" TEXT NOT NULL,
	"descricao" TEXT,
	"foto_path" TEXT,
	"foto_capa_path" TEXT,
	"usuario_id" UUID NOT NULL,
	"entidade_id" UUID NOT NULL,
	"papel_id" UUID NOT NULL,
	"ativo" BOOLEAN NOT NULL,
	"created_at" TIMESTAMP NOT NULL,
	"created_by" UUID NOT NULL,
	"updated_at" TIMESTAMP,
	"updated_by" UUID,
	"deleted_at" TIMESTAMP,
	"deleted_by" UUID,
	PRIMARY KEY("id")
);

COMMENT ON TABLE "usuario_perfil" IS 'Tabela para armazenar os perfis do usuário.';