package com.github.reinternals.local_forms.user.dto;

public class UserDto {
}
