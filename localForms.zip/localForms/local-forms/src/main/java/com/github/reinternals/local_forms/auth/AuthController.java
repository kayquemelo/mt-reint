package com.github.reinternals.local_forms.auth;

public class AuthController {
}
