package com.github.reinternals.local_forms.audit.repository;

public class AuditRepository {
}
