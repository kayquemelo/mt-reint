package com.github.reinternals.local_forms.tenant.dto;

public record TenantFindResponseDto(

) {}
