package com.github.reinternals.local_forms.profile.dto;

public class ProfileDto {
}
