package com.github.reinternals.local_forms.user.entity;

public class UserEntity {
}
