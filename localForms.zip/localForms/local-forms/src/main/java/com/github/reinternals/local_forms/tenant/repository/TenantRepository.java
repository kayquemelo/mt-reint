package com.github.reinternals.local_forms.tenant.repository;

import com.github.reinternals.local_forms.tenant.entity.TenantEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TenantRepository extends JpaRepository<TenantEntity, String> {

}
