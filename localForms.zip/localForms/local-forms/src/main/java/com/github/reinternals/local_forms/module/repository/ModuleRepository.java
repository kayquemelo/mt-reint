package com.github.reinternals.local_forms.module.repository;

public class ModuleRepository {
}
