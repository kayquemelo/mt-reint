package com.github.reinternals.local_forms.rbac;

public class RbacService {
}
