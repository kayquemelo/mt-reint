package com.github.reinternals.local_forms.tenant.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity()
@Table(name = "entidade")
public class TenantEntity {
    @Id()
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(unique = true, nullable = false)
    private String codigo;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = true)
    private String descricao;

    @Column(nullable = true)
    private UUID entidade_id;

    @Column(nullable = true)
    private String hostname;

    @Column(nullable = true)
    private Integer limite_entidade;

    @Column(nullable = true)
    private Integer limite_usuario;

    @Column(nullable = true)
    private String cor_primaria;

    @Column(nullable = true)
    private String cor_secundaria;

    @Column(nullable = true)
    private String cor_terciaria;

    @Column(nullable = true)
    private String logo_path;

    @Column(nullable = true)
    private String email_conta;

    @Column(nullable = true)
    private String email_porta;

    @Column(nullable = true)
    private String email_senha;

    @Column(nullable = true)
    private Boolean ativo;

    @Column(nullable = true)
    private LocalDateTime created_at;

    @Column(nullable = true)
    private UUID created_by;

    @Column(nullable = true)
    private LocalDateTime updated_at;

    @Column(nullable = true)
    private UUID updated_by;

    @Column(nullable = true)
    private LocalDateTime deleted_at;

    @Column(nullable = true)
    private UUID deleted_by;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public UUID getEntidadeId() {
        return entidade_id;
    }

    public void setEntidadeId(UUID entidade_id) {
        this.entidade_id = entidade_id;
    }

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public Integer getLimiteEntidade() {
        return limite_entidade;
    }

    public void setLimiteEntidade(Integer limite_entidade) {
        this.limite_entidade = limite_entidade;
    }

    public Integer getLimiteUsuario() {
        return limite_usuario;
    }

    public void setLimiteUsuario(Integer limite_usuario) {
        this.limite_usuario = limite_usuario;
    }

    public String getCorPrimaria() {
        return cor_primaria;
    }

    public void setCorPrimaria(String cor_primaria) {
        this.cor_primaria = cor_primaria;
    }

    public String getCorSecundaria() {
        return cor_secundaria;
    }

    public void setCorSecundaria(String cor_secundaria) {
        this.cor_secundaria = cor_secundaria;
    }

    public String getCorTerciaria() {
        return cor_terciaria;
    }

    public void setCorTerciaria(String cor_terciaria) {
        this.cor_terciaria = cor_terciaria;
    }

    public String getLogoPath() {
        return logo_path;
    }

    public void setLogoPath(String logo_path) {
        this.logo_path = logo_path;
    }

    public String getEmailConta() {
        return email_conta;
    }

    public void setEmailConta(String email_conta) {
        this.email_conta = email_conta;
    }

    public String getEmailPorta() {
        return email_porta;
    }

    public void setEmailPorta(String email_porta) {
        this.email_porta = email_porta;
    }

    public String getEmailSenha() {
        return email_senha;
    }

    public void setEmailSenha(String email_senha) {
        this.email_senha = email_senha;
    }

    public Boolean getAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    public LocalDateTime getCreatedAt() {
        return created_at;
    }

    public void setCreatedAt(LocalDateTime created_at) {
        this.created_at = created_at;
    }

    public UUID getCreatedBy() {
        return created_by;
    }

    public void setCreatedBy(UUID created_by) {
        this.created_by = created_by;
    }

    public LocalDateTime getUpdatedAt() {
        return updated_at;
    }

    public void setUpdatedAt(LocalDateTime updated_at) {
        this.updated_at = updated_at;
    }

    public UUID getUpdatedBy() {
        return updated_by;
    }

    public void setUpdatedBy(UUID updated_by) {
        this.updated_by = updated_by;
    }

    public LocalDateTime getDeletedAt() {
        return deleted_at;
    }

    public void setDeletedAt(LocalDateTime deleted_at) {
        this.deleted_at = deleted_at;
    }

    public UUID getDeletedBy() {
        return deleted_by;
    }

    public void setDeletedBy(UUID deleted_by) {
        this.deleted_by = deleted_by;
    }
}
