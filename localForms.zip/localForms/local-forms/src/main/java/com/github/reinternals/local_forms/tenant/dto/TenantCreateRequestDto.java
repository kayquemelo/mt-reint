package com.github.reinternals.local_forms.tenant.dto;

import java.util.UUID;

public record TenantCreateRequestDto(
        String nome,
        String descricao,
        String codigo,
        UUID entidade_id,
        String hostname,
        Integer limite_entidade,
        Integer limite_usuario,
        String cor_primaria,
        String cor_secundaria,
        String cor_terciaria,
        String logo_path,
        String email_conta,
        String email_porta,
        String email_senha
) {}
