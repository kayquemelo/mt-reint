package com.github.reinternals.local_forms.module.dto;

public class ModuleDto {
}
