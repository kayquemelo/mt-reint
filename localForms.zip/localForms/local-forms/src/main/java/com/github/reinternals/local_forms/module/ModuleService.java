package com.github.reinternals.local_forms.module;

public class ModuleService {
}
