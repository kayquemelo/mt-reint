package com.github.reinternals.local_forms.user.repository;

public class UserRepository {
}
