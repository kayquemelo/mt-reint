package com.github.reinternals.local_forms.profile.entity;

public class ProfileEntity {
}
