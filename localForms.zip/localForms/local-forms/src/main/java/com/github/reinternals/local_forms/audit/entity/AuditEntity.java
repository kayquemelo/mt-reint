package com.github.reinternals.local_forms.audit.entity;

public class AuditEntity {
}
