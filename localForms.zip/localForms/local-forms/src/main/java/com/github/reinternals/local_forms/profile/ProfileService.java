package com.github.reinternals.local_forms.profile;

public class ProfileService {
}
