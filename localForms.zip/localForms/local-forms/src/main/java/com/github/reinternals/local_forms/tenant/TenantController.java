package com.github.reinternals.local_forms.tenant;

import com.github.reinternals.local_forms.tenant.dto.TenantCreateRequestDto;
import com.github.reinternals.local_forms.tenant.dto.TenantCreateResponseDto;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/entidade")
public class TenantController {

    private final TenantService tenantService;

    public TenantController(TenantService tenantService) {
        this.tenantService = tenantService;
    }

    @PostMapping
    public TenantCreateResponseDto create(@RequestBody TenantCreateRequestDto dto) {
        return this.tenantService.create(dto);
    }

}
