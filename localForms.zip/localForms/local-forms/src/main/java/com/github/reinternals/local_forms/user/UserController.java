package com.github.reinternals.local_forms.user;

public class UserController {
}
