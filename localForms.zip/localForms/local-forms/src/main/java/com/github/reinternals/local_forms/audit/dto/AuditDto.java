package com.github.reinternals.local_forms.audit.dto;

public class AuditDto {
}
