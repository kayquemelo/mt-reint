package com.github.reinternals.local_forms.profile.repository;

public class ProfileRepository {
}
