package com.github.reinternals.local_forms.tenant.dto;

import java.util.UUID;

public record TenantCreateResponseDto(
    UUID id
) {}
