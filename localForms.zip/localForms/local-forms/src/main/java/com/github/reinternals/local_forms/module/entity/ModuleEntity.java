package com.github.reinternals.local_forms.module.entity;

public class ModuleEntity {
}
