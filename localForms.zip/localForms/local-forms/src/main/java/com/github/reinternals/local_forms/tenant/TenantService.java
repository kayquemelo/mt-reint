package com.github.reinternals.local_forms.tenant;

import com.github.reinternals.local_forms.tenant.dto.TenantCreateRequestDto;
import com.github.reinternals.local_forms.tenant.dto.TenantCreateResponseDto;
import com.github.reinternals.local_forms.tenant.entity.TenantEntity;
import com.github.reinternals.local_forms.tenant.repository.TenantRepository;
import org.springframework.stereotype.Service;

@Service()
public class TenantService {

    private final TenantRepository tenantRepository;

    public TenantService(TenantRepository tenantRepository) {
        this.tenantRepository = tenantRepository;
    }

    public TenantCreateResponseDto create(TenantCreateRequestDto dto) {
        TenantEntity tenantEntity = new TenantEntity();
        tenantEntity.setNome(dto.nome());
        tenantEntity.setDescricao(dto.descricao());
        tenantEntity.setCodigo(dto.codigo());
        tenantEntity.setEntidadeId(dto.entidade_id());
        tenantEntity.setHostname(dto.hostname());
        tenantEntity.setLimiteEntidade(dto.limite_entidade());
        tenantEntity.setLimiteUsuario(dto.limite_usuario());
        tenantEntity.setCorPrimaria(dto.cor_primaria());
        tenantEntity.setCorSecundaria(dto.cor_secundaria());
        tenantEntity.setCorTerciaria(dto.cor_terciaria());
        tenantEntity.setLogoPath(dto.logo_path());
        tenantEntity.setEmailConta(dto.email_conta());
        tenantEntity.setEmailPorta(dto.email_porta());
        tenantEntity.setEmailSenha(dto.email_senha());

        TenantEntity tenantSave = tenantRepository.save(tenantEntity);

        return new TenantCreateResponseDto(
                tenantSave.getId()
        );
    }

}
