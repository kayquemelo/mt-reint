package com.github.reinternals.local_forms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocalFormsApplicationTests {

	@Test
	void contextLoads() {
	}

}
